const section = document.getElementById ('main');
section.style.background = 'blue';
section.style.padding = '0';
section.style.margin = '0';
section.style.display = 'flex';

const modal = document.querySelector(".modal");
const openBtn = document.getElementById("btn-open");
const closeButton = document.querySelector(".closeButton");

openBtn.addEventListener("click", toggleModal);
closeButton.addEventListener("click", toggleModal);
window.addEventListener("click", windowOnClick);

function toggleModal() {
	modal.classList.toggle("show-modal");
}

function windowOnClick(event){
	if (event.target === modal){
		toggleModal();
	}
}